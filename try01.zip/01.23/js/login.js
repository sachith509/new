function validateData(){
    let UN= document.getElementById("username").value;
    let pw=document.getElementById("password").value;

    if(UN=="sachith" && pw=="123"){

        alert("login successfully!!")

    }else {
        alert("incorrect username or password!!")
    }
}

 document.getElementById("btnlog").onclick= function(){

     validateData();
 }
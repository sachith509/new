function getDetails(){

}
